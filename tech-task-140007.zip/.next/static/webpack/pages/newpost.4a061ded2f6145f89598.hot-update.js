"use strict";
self["webpackHotUpdate_N_E"]("pages/newpost",{

/***/ "./components/inputText.jsx":
/*!**********************************!*\
  !*** ./components/inputText.jsx ***!
  \**********************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_new_code_exam_project_tech_task_140007_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/TextField */ "./node_modules/@material-ui/core/esm/TextField/index.js");
/* harmony import */ var _context_formContex__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/context/formContex */ "./context/formContex.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "D:\\new code\\exam project\\tech-task-140007\\components\\inputText.jsx",
    _this = undefined,
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,D_new_code_exam_project_tech_task_140007_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }






var InputText = function InputText(props) {
  _s();

  var name = props.name,
      _props$type = props.type,
      type = _props$type === void 0 ? "text" : _props$type;
  var formContext = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_formContex__WEBPACK_IMPORTED_MODULE_2__.FormContext);
  var form = formContext.form,
      handleInputChange = formContext.handleInputChange;
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_4__.default, _objectSpread({
    variant: "outlined",
    margin: "normal",
    inputProps: {
      autoComplete: "none"
    },
    name: name,
    value: form[name],
    onChange: handleInputChange,
    type: type
  }, props), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, _this);
};

_s(InputText, "PcqHVQMN7gMwJTcYWIt9tOKJP/0=");

_c = InputText;
/* harmony default export */ __webpack_exports__["default"] = (InputText);

var _c;

$RefreshReg$(_c, "InputText");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvbmV3cG9zdC40YTA2MWRlZDJmNjE0NWY4OTU5OC5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7OztBQUNBLElBQU1HLFNBQVMsR0FBRyxTQUFaQSxTQUFZLENBQUNDLEtBQUQsRUFBVztBQUFBOztBQUMzQixNQUFRQyxJQUFSLEdBQWdDRCxLQUFoQyxDQUFRQyxJQUFSO0FBQUEsb0JBQWdDRCxLQUFoQyxDQUFjRSxJQUFkO0FBQUEsTUFBY0EsSUFBZCw0QkFBcUIsTUFBckI7QUFDQSxNQUFNQyxXQUFXLEdBQUdQLGlEQUFVLENBQUNFLDREQUFELENBQTlCO0FBQ0EsTUFBUU0sSUFBUixHQUFvQ0QsV0FBcEMsQ0FBUUMsSUFBUjtBQUFBLE1BQWNDLGlCQUFkLEdBQW9DRixXQUFwQyxDQUFjRSxpQkFBZDtBQUNBLHNCQUNFLDhEQUFDLGdFQUFEO0FBQ0UsV0FBTyxFQUFDLFVBRFY7QUFFRSxVQUFNLEVBQUMsUUFGVDtBQUdFLGNBQVUsRUFBRTtBQUNWQyxNQUFBQSxZQUFZLEVBQUU7QUFESixLQUhkO0FBTUUsUUFBSSxFQUFFTCxJQU5SO0FBT0UsU0FBSyxFQUFFRyxJQUFJLENBQUNILElBQUQsQ0FQYjtBQVFFLFlBQVEsRUFBRUksaUJBUlo7QUFTRSxRQUFJLEVBQUVIO0FBVFIsS0FVTUYsS0FWTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFjRCxDQWxCRDs7R0FBTUQ7O0tBQUFBO0FBbUJOLCtEQUFlQSxTQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL2NvbXBvbmVudHMvaW5wdXRUZXh0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDb250ZXh0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBUZXh0RmllbGQgZnJvbSBcIkBtYXRlcmlhbC11aS9jb3JlL1RleHRGaWVsZFwiO1xyXG5pbXBvcnQgeyBGb3JtQ29udGV4dCB9IGZyb20gXCJAL2NvbnRleHQvZm9ybUNvbnRleFwiO1xyXG5jb25zdCBJbnB1dFRleHQgPSAocHJvcHMpID0+IHtcclxuICBjb25zdCB7IG5hbWUsIHR5cGUgPSBcInRleHRcIiB9ID0gcHJvcHM7XHJcbiAgY29uc3QgZm9ybUNvbnRleHQgPSB1c2VDb250ZXh0KEZvcm1Db250ZXh0KTtcclxuICBjb25zdCB7IGZvcm0sIGhhbmRsZUlucHV0Q2hhbmdlIH0gPSBmb3JtQ29udGV4dDtcclxuICByZXR1cm4gKFxyXG4gICAgPFRleHRGaWVsZFxyXG4gICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxyXG4gICAgICBtYXJnaW49XCJub3JtYWxcIlxyXG4gICAgICBpbnB1dFByb3BzPXt7XHJcbiAgICAgICAgYXV0b0NvbXBsZXRlOiBcIm5vbmVcIixcclxuICAgICAgfX1cclxuICAgICAgbmFtZT17bmFtZX1cclxuICAgICAgdmFsdWU9e2Zvcm1bbmFtZV19XHJcbiAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgdHlwZT17dHlwZX1cclxuICAgICAgey4uLnByb3BzfVxyXG4gICAgLz5cclxuICApO1xyXG59O1xyXG5leHBvcnQgZGVmYXVsdCBJbnB1dFRleHQ7XHJcbiJdLCJuYW1lcyI6WyJ1c2VDb250ZXh0IiwiVGV4dEZpZWxkIiwiRm9ybUNvbnRleHQiLCJJbnB1dFRleHQiLCJwcm9wcyIsIm5hbWUiLCJ0eXBlIiwiZm9ybUNvbnRleHQiLCJmb3JtIiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJhdXRvQ29tcGxldGUiXSwic291cmNlUm9vdCI6IiJ9