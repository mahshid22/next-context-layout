"use strict";
self["webpackHotUpdate_N_E"]("pages/newpost",{

/***/ "./components/submitButton.jsx":
/*!*************************************!*\
  !*** ./components/submitButton.jsx ***!
  \*************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_new_code_exam_project_tech_task_140007_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/material/Button */ "./node_modules/@mui/material/Button/index.js");
/* harmony import */ var _context_formContex__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/context/formContex */ "./context/formContex.jsx");
/* harmony import */ var _context_alertCotex__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/context/alertCotex */ "./context/alertCotex.jsx");
/* harmony import */ var _context_resultContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/context/resultContext */ "./context/resultContext.jsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "D:\\new code\\exam project\\tech-task-140007\\components\\submitButton.jsx",
    _this = undefined,
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,D_new_code_exam_project_tech_task_140007_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }









var SubmitButton = function SubmitButton() {
  _s();

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false),
      loading = _useState[0],
      setLoading = _useState[1];

  var formContext = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_formContex__WEBPACK_IMPORTED_MODULE_3__.FormContext);
  var form = formContext.form;

  var _useContext = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_resultContext__WEBPACK_IMPORTED_MODULE_5__.ResultContext),
      result = _useContext.result,
      setResult = _useContext.setResult;

  var _useContext2 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_alertCotex__WEBPACK_IMPORTED_MODULE_4__.AlertContext),
      setShowSubmitResult = _useContext2.setShowSubmitResult,
      setAlertMsg = _useContext2.setAlertMsg,
      setAlertMsgType = _useContext2.setAlertMsgType;

  var handleSubmit = function handleSubmit() {
    console.log(JSON.stringify(form));

    if (JSON.stringify(form) !== JSON.stringify(result) && removeEmpty(form)) {
      setLoading(true);
      setShowSubmitResult(false);
      axios__WEBPACK_IMPORTED_MODULE_2___default().post("https://jsonplaceholder.typicode.com/posts", form, {
        headers: {
          "Content-type": "application/json; charset=UTF-8"
        }
      }).then(function (result) {
        delete result.data.id;

        var res = _objectSpread({}, result.data);

        setShowSubmitResult(true);
        setLoading(false);
        setAlertMsg("you're message was submited successfully");
        setAlertMsgType("success");
        setResult(res);
      })["catch"](function () {
        setShowSubmitResult(true);
        setLoading(false);
        setAlertMsg("you're message was NOT submited.");
        setAlertMsgType("error");
      });
    } else {
      setAlertMsg(" Duplicate or Empty information");
      setAlertMsgType("error");
      setShowSubmitResult(true);
    }
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(_mui_material_Button__WEBPACK_IMPORTED_MODULE_7__.default, {
    variant: "contained",
    onClick: handleSubmit,
    disabled: loading,
    children: "Submit"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 48,
    columnNumber: 5
  }, _this);
};

_s(SubmitButton, "fPGiZkaYS7ReBlaCUxg9HsRTapU=");

_c = SubmitButton;
/* harmony default export */ __webpack_exports__["default"] = (SubmitButton);

var _c;

$RefreshReg$(_c, "SubmitButton");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvbmV3cG9zdC5lYzQ1NjVjZTk3ZGUyYzc3ZjZiNS5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFFQSxJQUFNTyxZQUFZLEdBQUcsU0FBZkEsWUFBZSxHQUFNO0FBQUE7O0FBQ3pCLGtCQUE4QlAsK0NBQVEsQ0FBQyxLQUFELENBQXRDO0FBQUEsTUFBT1EsT0FBUDtBQUFBLE1BQWdCQyxVQUFoQjs7QUFDQSxNQUFNQyxXQUFXLEdBQUdULGlEQUFVLENBQUNHLDREQUFELENBQTlCO0FBQ0EsTUFBUU8sSUFBUixHQUFpQkQsV0FBakIsQ0FBUUMsSUFBUjs7QUFDQSxvQkFBOEJWLGlEQUFVLENBQUNLLGlFQUFELENBQXhDO0FBQUEsTUFBUU0sTUFBUixlQUFRQSxNQUFSO0FBQUEsTUFBZ0JDLFNBQWhCLGVBQWdCQSxTQUFoQjs7QUFDQSxxQkFDRVosaURBQVUsQ0FBQ0ksNkRBQUQsQ0FEWjtBQUFBLE1BQVFTLG1CQUFSLGdCQUFRQSxtQkFBUjtBQUFBLE1BQTZCQyxXQUE3QixnQkFBNkJBLFdBQTdCO0FBQUEsTUFBMENDLGVBQTFDLGdCQUEwQ0EsZUFBMUM7O0FBRUEsTUFBTUMsWUFBWSxHQUFHLFNBQWZBLFlBQWUsR0FBTTtBQUN6QkMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlDLElBQUksQ0FBQ0MsU0FBTCxDQUFlVixJQUFmLENBQVo7O0FBQ0EsUUFBSVMsSUFBSSxDQUFDQyxTQUFMLENBQWVWLElBQWYsTUFBeUJTLElBQUksQ0FBQ0MsU0FBTCxDQUFlVCxNQUFmLENBQXpCLElBQW1EVSxXQUFXLENBQUNYLElBQUQsQ0FBbEUsRUFBMEU7QUFDeEVGLE1BQUFBLFVBQVUsQ0FBQyxJQUFELENBQVY7QUFDQUssTUFBQUEsbUJBQW1CLENBQUMsS0FBRCxDQUFuQjtBQUNBWixNQUFBQSxpREFBQSxDQUNRLDRDQURSLEVBQ3NEUyxJQUR0RCxFQUM0RDtBQUN4RGEsUUFBQUEsT0FBTyxFQUFFO0FBQ1AsMEJBQWdCO0FBRFQ7QUFEK0MsT0FENUQsRUFNR0MsSUFOSCxDQU1RLFVBQUNiLE1BQUQsRUFBWTtBQUNoQixlQUFPQSxNQUFNLENBQUNjLElBQVAsQ0FBWUMsRUFBbkI7O0FBQ0EsWUFBSUMsR0FBRyxxQkFBUWhCLE1BQU0sQ0FBQ2MsSUFBZixDQUFQOztBQUNBWixRQUFBQSxtQkFBbUIsQ0FBQyxJQUFELENBQW5CO0FBQ0FMLFFBQUFBLFVBQVUsQ0FBQyxLQUFELENBQVY7QUFDQU0sUUFBQUEsV0FBVyxDQUFDLDBDQUFELENBQVg7QUFDQUMsUUFBQUEsZUFBZSxDQUFDLFNBQUQsQ0FBZjtBQUNBSCxRQUFBQSxTQUFTLENBQUNlLEdBQUQsQ0FBVDtBQUNELE9BZEgsV0FlUyxZQUFNO0FBQ1hkLFFBQUFBLG1CQUFtQixDQUFDLElBQUQsQ0FBbkI7QUFDQUwsUUFBQUEsVUFBVSxDQUFDLEtBQUQsQ0FBVjtBQUNBTSxRQUFBQSxXQUFXLENBQUMsa0NBQUQsQ0FBWDtBQUNBQyxRQUFBQSxlQUFlLENBQUMsT0FBRCxDQUFmO0FBQ0QsT0FwQkg7QUFxQkQsS0F4QkQsTUF3Qk87QUFDTEQsTUFBQUEsV0FBVyxDQUFDLGlDQUFELENBQVg7QUFDQUMsTUFBQUEsZUFBZSxDQUFDLE9BQUQsQ0FBZjtBQUNBRixNQUFBQSxtQkFBbUIsQ0FBQyxJQUFELENBQW5CO0FBQ0Q7QUFDRixHQS9CRDs7QUFnQ0Esc0JBQ0UsOERBQUMseURBQUQ7QUFBUSxXQUFPLEVBQUMsV0FBaEI7QUFBNEIsV0FBTyxFQUFFRyxZQUFyQztBQUFtRCxZQUFRLEVBQUVULE9BQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFLRCxDQTVDRDs7R0FBTUQ7O0tBQUFBO0FBNkNOLCtEQUFlQSxZQUFmIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL2NvbXBvbmVudHMvc3VibWl0QnV0dG9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlQ29udGV4dCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCBCdXR0b24gZnJvbSBcIkBtdWkvbWF0ZXJpYWwvQnV0dG9uXCI7XHJcbmltcG9ydCB7IEZvcm1Db250ZXh0IH0gZnJvbSBcIkAvY29udGV4dC9mb3JtQ29udGV4XCI7XHJcbmltcG9ydCB7IEFsZXJ0Q29udGV4dCB9IGZyb20gXCJAL2NvbnRleHQvYWxlcnRDb3RleFwiO1xyXG5pbXBvcnQgeyBSZXN1bHRDb250ZXh0IH0gZnJvbSBcIkAvY29udGV4dC9yZXN1bHRDb250ZXh0XCI7XHJcblxyXG5jb25zdCBTdWJtaXRCdXR0b24gPSAoKSA9PiB7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IGZvcm1Db250ZXh0ID0gdXNlQ29udGV4dChGb3JtQ29udGV4dCk7XHJcbiAgY29uc3QgeyBmb3JtIH0gPSBmb3JtQ29udGV4dDtcclxuICBjb25zdCB7IHJlc3VsdCwgc2V0UmVzdWx0IH0gPSB1c2VDb250ZXh0KFJlc3VsdENvbnRleHQpO1xyXG4gIGNvbnN0IHsgc2V0U2hvd1N1Ym1pdFJlc3VsdCwgc2V0QWxlcnRNc2csIHNldEFsZXJ0TXNnVHlwZSB9ID1cclxuICAgIHVzZUNvbnRleHQoQWxlcnRDb250ZXh0KTtcclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSAoKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShmb3JtKSk7XHJcbiAgICBpZiAoSlNPTi5zdHJpbmdpZnkoZm9ybSkgIT09IEpTT04uc3RyaW5naWZ5KHJlc3VsdCkgJiYgcmVtb3ZlRW1wdHkoZm9ybSkpIHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgc2V0U2hvd1N1Ym1pdFJlc3VsdChmYWxzZSk7XHJcbiAgICAgIGF4aW9zXHJcbiAgICAgICAgLnBvc3QoXCJodHRwczovL2pzb25wbGFjZWhvbGRlci50eXBpY29kZS5jb20vcG9zdHNcIiwgZm9ybSwge1xyXG4gICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICBcIkNvbnRlbnQtdHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb247IGNoYXJzZXQ9VVRGLThcIixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSlcclxuICAgICAgICAudGhlbigocmVzdWx0KSA9PiB7XHJcbiAgICAgICAgICBkZWxldGUgcmVzdWx0LmRhdGEuaWQ7XHJcbiAgICAgICAgICBsZXQgcmVzID0geyAuLi5yZXN1bHQuZGF0YSB9O1xyXG4gICAgICAgICAgc2V0U2hvd1N1Ym1pdFJlc3VsdCh0cnVlKTtcclxuICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0QWxlcnRNc2coXCJ5b3UncmUgbWVzc2FnZSB3YXMgc3VibWl0ZWQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4gICAgICAgICAgc2V0QWxlcnRNc2dUeXBlKFwic3VjY2Vzc1wiKTtcclxuICAgICAgICAgIHNldFJlc3VsdChyZXMpO1xyXG4gICAgICAgIH0pXHJcbiAgICAgICAgLmNhdGNoKCgpID0+IHtcclxuICAgICAgICAgIHNldFNob3dTdWJtaXRSZXN1bHQodHJ1ZSk7XHJcbiAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICAgIHNldEFsZXJ0TXNnKFwieW91J3JlIG1lc3NhZ2Ugd2FzIE5PVCBzdWJtaXRlZC5cIik7XHJcbiAgICAgICAgICBzZXRBbGVydE1zZ1R5cGUoXCJlcnJvclwiKTtcclxuICAgICAgICB9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEFsZXJ0TXNnKFwiIER1cGxpY2F0ZSBvciBFbXB0eSBpbmZvcm1hdGlvblwiKTtcclxuICAgICAgc2V0QWxlcnRNc2dUeXBlKFwiZXJyb3JcIik7XHJcbiAgICAgIHNldFNob3dTdWJtaXRSZXN1bHQodHJ1ZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuICByZXR1cm4gKFxyXG4gICAgPEJ1dHRvbiB2YXJpYW50PVwiY29udGFpbmVkXCIgb25DbGljaz17aGFuZGxlU3VibWl0fSBkaXNhYmxlZD17bG9hZGluZ30+XHJcbiAgICAgIFN1Ym1pdFxyXG4gICAgPC9CdXR0b24+XHJcbiAgKTtcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgU3VibWl0QnV0dG9uO1xyXG4iXSwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VDb250ZXh0IiwiYXhpb3MiLCJCdXR0b24iLCJGb3JtQ29udGV4dCIsIkFsZXJ0Q29udGV4dCIsIlJlc3VsdENvbnRleHQiLCJTdWJtaXRCdXR0b24iLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImZvcm1Db250ZXh0IiwiZm9ybSIsInJlc3VsdCIsInNldFJlc3VsdCIsInNldFNob3dTdWJtaXRSZXN1bHQiLCJzZXRBbGVydE1zZyIsInNldEFsZXJ0TXNnVHlwZSIsImhhbmRsZVN1Ym1pdCIsImNvbnNvbGUiLCJsb2ciLCJKU09OIiwic3RyaW5naWZ5IiwicmVtb3ZlRW1wdHkiLCJwb3N0IiwiaGVhZGVycyIsInRoZW4iLCJkYXRhIiwiaWQiLCJyZXMiXSwic291cmNlUm9vdCI6IiJ9