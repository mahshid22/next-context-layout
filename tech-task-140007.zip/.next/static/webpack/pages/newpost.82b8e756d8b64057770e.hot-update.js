"use strict";
self["webpackHotUpdate_N_E"]("pages/newpost",{

/***/ "./components/submitButton.jsx":
/*!*************************************!*\
  !*** ./components/submitButton.jsx ***!
  \*************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_new_code_exam_project_tech_task_140007_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/material/Button */ "./node_modules/@mui/material/Button/index.js");
/* harmony import */ var _context_formContex__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/context/formContex */ "./context/formContex.jsx");
/* harmony import */ var _context_alertCotex__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @/context/alertCotex */ "./context/alertCotex.jsx");
/* harmony import */ var _context_resultContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @/context/resultContext */ "./context/resultContext.jsx");
/* harmony import */ var utils_removeEmptyFromObject__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! utils/removeEmptyFromObject */ "./utils/removeEmptyFromObject.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);
/* module decorator */ module = __webpack_require__.hmd(module);


var _jsxFileName = "D:\\new code\\exam project\\tech-task-140007\\components\\submitButton.jsx",
    _this = undefined,
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { (0,D_new_code_exam_project_tech_task_140007_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_0__.default)(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }










var SubmitButton = function SubmitButton() {
  _s();

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false),
      loading = _useState[0],
      setLoading = _useState[1];

  var formContext = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_formContex__WEBPACK_IMPORTED_MODULE_3__.FormContext);
  var form = formContext.form;

  var _useContext = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_resultContext__WEBPACK_IMPORTED_MODULE_5__.ResultContext),
      result = _useContext.result,
      setResult = _useContext.setResult;

  var _useContext2 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_alertCotex__WEBPACK_IMPORTED_MODULE_4__.AlertContext),
      setShowSubmitResult = _useContext2.setShowSubmitResult,
      setAlertMsg = _useContext2.setAlertMsg,
      setAlertMsgType = _useContext2.setAlertMsgType;

  var handleSubmit = function handleSubmit() {
    // actually a handles form with react hook forms :)
    if (JSON.stringify(form) !== JSON.stringify(result) && Object.keys((0,utils_removeEmptyFromObject__WEBPACK_IMPORTED_MODULE_6__.default)(form)).length) {
      setLoading(true);
      setShowSubmitResult(false);
      axios__WEBPACK_IMPORTED_MODULE_2___default().post("https://jsonplaceholder.typicode.com/posts", form, {
        headers: {
          "Content-type": "application/json; charset=UTF-8"
        }
      }).then(function (result) {
        delete result.data.id;

        var res = _objectSpread({}, result.data);

        setShowSubmitResult(true);
        setLoading(false);
        setAlertMsg("you're message was submited successfully");
        setAlertMsgType("success");
        setResult(res);
      })["catch"](function () {
        setShowSubmitResult(true);
        setLoading(false);
        setAlertMsg("you're message was NOT submited.");
        setAlertMsgType("error");
      });
    } else {
      setAlertMsg(" Duplicate or Empty information");
      setAlertMsgType("error");
      setShowSubmitResult(true);
    }
  };

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(_mui_material_Button__WEBPACK_IMPORTED_MODULE_8__.default, {
    variant: "contained",
    onClick: handleSubmit,
    disabled: loading,
    children: "Submit"
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 51,
    columnNumber: 5
  }, _this);
};

_s(SubmitButton, "fPGiZkaYS7ReBlaCUxg9HsRTapU=");

_c = SubmitButton;
/* harmony default export */ __webpack_exports__["default"] = (SubmitButton);

var _c;

$RefreshReg$(_c, "SubmitButton");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvbmV3cG9zdC44MmI4ZTc1NmQ4YjY0MDU3NzcwZS5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxJQUFNUSxZQUFZLEdBQUcsU0FBZkEsWUFBZSxHQUFNO0FBQUE7O0FBQ3pCLGtCQUE4QlIsK0NBQVEsQ0FBQyxLQUFELENBQXRDO0FBQUEsTUFBT1MsT0FBUDtBQUFBLE1BQWdCQyxVQUFoQjs7QUFDQSxNQUFNQyxXQUFXLEdBQUdWLGlEQUFVLENBQUNHLDREQUFELENBQTlCO0FBQ0EsTUFBUVEsSUFBUixHQUFpQkQsV0FBakIsQ0FBUUMsSUFBUjs7QUFDQSxvQkFBOEJYLGlEQUFVLENBQUNLLGlFQUFELENBQXhDO0FBQUEsTUFBUU8sTUFBUixlQUFRQSxNQUFSO0FBQUEsTUFBZ0JDLFNBQWhCLGVBQWdCQSxTQUFoQjs7QUFDQSxxQkFDRWIsaURBQVUsQ0FBQ0ksNkRBQUQsQ0FEWjtBQUFBLE1BQVFVLG1CQUFSLGdCQUFRQSxtQkFBUjtBQUFBLE1BQTZCQyxXQUE3QixnQkFBNkJBLFdBQTdCO0FBQUEsTUFBMENDLGVBQTFDLGdCQUEwQ0EsZUFBMUM7O0FBRUEsTUFBTUMsWUFBWSxHQUFHLFNBQWZBLFlBQWUsR0FBTTtBQUN6QjtBQUNBLFFBQ0VDLElBQUksQ0FBQ0MsU0FBTCxDQUFlUixJQUFmLE1BQXlCTyxJQUFJLENBQUNDLFNBQUwsQ0FBZVAsTUFBZixDQUF6QixJQUNBUSxNQUFNLENBQUNDLElBQVAsQ0FBWWYsb0VBQVcsQ0FBQ0ssSUFBRCxDQUF2QixFQUErQlcsTUFGakMsRUFHRTtBQUNBYixNQUFBQSxVQUFVLENBQUMsSUFBRCxDQUFWO0FBQ0FLLE1BQUFBLG1CQUFtQixDQUFDLEtBQUQsQ0FBbkI7QUFDQWIsTUFBQUEsaURBQUEsQ0FDUSw0Q0FEUixFQUNzRFUsSUFEdEQsRUFDNEQ7QUFDeERhLFFBQUFBLE9BQU8sRUFBRTtBQUNQLDBCQUFnQjtBQURUO0FBRCtDLE9BRDVELEVBTUdDLElBTkgsQ0FNUSxVQUFDYixNQUFELEVBQVk7QUFDaEIsZUFBT0EsTUFBTSxDQUFDYyxJQUFQLENBQVlDLEVBQW5COztBQUNBLFlBQUlDLEdBQUcscUJBQVFoQixNQUFNLENBQUNjLElBQWYsQ0FBUDs7QUFDQVosUUFBQUEsbUJBQW1CLENBQUMsSUFBRCxDQUFuQjtBQUNBTCxRQUFBQSxVQUFVLENBQUMsS0FBRCxDQUFWO0FBQ0FNLFFBQUFBLFdBQVcsQ0FBQywwQ0FBRCxDQUFYO0FBQ0FDLFFBQUFBLGVBQWUsQ0FBQyxTQUFELENBQWY7QUFDQUgsUUFBQUEsU0FBUyxDQUFDZSxHQUFELENBQVQ7QUFDRCxPQWRILFdBZVMsWUFBTTtBQUNYZCxRQUFBQSxtQkFBbUIsQ0FBQyxJQUFELENBQW5CO0FBQ0FMLFFBQUFBLFVBQVUsQ0FBQyxLQUFELENBQVY7QUFDQU0sUUFBQUEsV0FBVyxDQUFDLGtDQUFELENBQVg7QUFDQUMsUUFBQUEsZUFBZSxDQUFDLE9BQUQsQ0FBZjtBQUNELE9BcEJIO0FBcUJELEtBM0JELE1BMkJPO0FBQ0xELE1BQUFBLFdBQVcsQ0FBQyxpQ0FBRCxDQUFYO0FBQ0FDLE1BQUFBLGVBQWUsQ0FBQyxPQUFELENBQWY7QUFDQUYsTUFBQUEsbUJBQW1CLENBQUMsSUFBRCxDQUFuQjtBQUNEO0FBQ0YsR0FsQ0Q7O0FBbUNBLHNCQUNFLDhEQUFDLHlEQUFEO0FBQVEsV0FBTyxFQUFDLFdBQWhCO0FBQTRCLFdBQU8sRUFBRUcsWUFBckM7QUFBbUQsWUFBUSxFQUFFVCxPQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBS0QsQ0EvQ0Q7O0dBQU1EOztLQUFBQTtBQWdETiwrREFBZUEsWUFBZiIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9jb21wb25lbnRzL3N1Ym1pdEJ1dHRvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUNvbnRleHQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xyXG5pbXBvcnQgQnV0dG9uIGZyb20gXCJAbXVpL21hdGVyaWFsL0J1dHRvblwiO1xyXG5pbXBvcnQgeyBGb3JtQ29udGV4dCB9IGZyb20gXCJAL2NvbnRleHQvZm9ybUNvbnRleFwiO1xyXG5pbXBvcnQgeyBBbGVydENvbnRleHQgfSBmcm9tIFwiQC9jb250ZXh0L2FsZXJ0Q290ZXhcIjtcclxuaW1wb3J0IHsgUmVzdWx0Q29udGV4dCB9IGZyb20gXCJAL2NvbnRleHQvcmVzdWx0Q29udGV4dFwiO1xyXG5pbXBvcnQgcmVtb3ZlRW1wdHkgZnJvbSBcInV0aWxzL3JlbW92ZUVtcHR5RnJvbU9iamVjdFwiO1xyXG5jb25zdCBTdWJtaXRCdXR0b24gPSAoKSA9PiB7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IGZvcm1Db250ZXh0ID0gdXNlQ29udGV4dChGb3JtQ29udGV4dCk7XHJcbiAgY29uc3QgeyBmb3JtIH0gPSBmb3JtQ29udGV4dDtcclxuICBjb25zdCB7IHJlc3VsdCwgc2V0UmVzdWx0IH0gPSB1c2VDb250ZXh0KFJlc3VsdENvbnRleHQpO1xyXG4gIGNvbnN0IHsgc2V0U2hvd1N1Ym1pdFJlc3VsdCwgc2V0QWxlcnRNc2csIHNldEFsZXJ0TXNnVHlwZSB9ID1cclxuICAgIHVzZUNvbnRleHQoQWxlcnRDb250ZXh0KTtcclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSAoKSA9PiB7XHJcbiAgICAvLyBhY3R1YWxseSBhIGhhbmRsZXMgZm9ybSB3aXRoIHJlYWN0IGhvb2sgZm9ybXMgOilcclxuICAgIGlmIChcclxuICAgICAgSlNPTi5zdHJpbmdpZnkoZm9ybSkgIT09IEpTT04uc3RyaW5naWZ5KHJlc3VsdCkgJiZcclxuICAgICAgT2JqZWN0LmtleXMocmVtb3ZlRW1wdHkoZm9ybSkpLmxlbmd0aFxyXG4gICAgKSB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIHNldFNob3dTdWJtaXRSZXN1bHQoZmFsc2UpO1xyXG4gICAgICBheGlvc1xyXG4gICAgICAgIC5wb3N0KFwiaHR0cHM6Ly9qc29ucGxhY2Vob2xkZXIudHlwaWNvZGUuY29tL3Bvc3RzXCIsIGZvcm0sIHtcclxuICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgXCJDb250ZW50LXR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uOyBjaGFyc2V0PVVURi04XCIsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgLnRoZW4oKHJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgZGVsZXRlIHJlc3VsdC5kYXRhLmlkO1xyXG4gICAgICAgICAgbGV0IHJlcyA9IHsgLi4ucmVzdWx0LmRhdGEgfTtcclxuICAgICAgICAgIHNldFNob3dTdWJtaXRSZXN1bHQodHJ1ZSk7XHJcbiAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICAgIHNldEFsZXJ0TXNnKFwieW91J3JlIG1lc3NhZ2Ugd2FzIHN1Ym1pdGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgICAgIHNldEFsZXJ0TXNnVHlwZShcInN1Y2Nlc3NcIik7XHJcbiAgICAgICAgICBzZXRSZXN1bHQocmVzKTtcclxuICAgICAgICB9KVxyXG4gICAgICAgIC5jYXRjaCgoKSA9PiB7XHJcbiAgICAgICAgICBzZXRTaG93U3VibWl0UmVzdWx0KHRydWUpO1xyXG4gICAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgICBzZXRBbGVydE1zZyhcInlvdSdyZSBtZXNzYWdlIHdhcyBOT1Qgc3VibWl0ZWQuXCIpO1xyXG4gICAgICAgICAgc2V0QWxlcnRNc2dUeXBlKFwiZXJyb3JcIik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRBbGVydE1zZyhcIiBEdXBsaWNhdGUgb3IgRW1wdHkgaW5mb3JtYXRpb25cIik7XHJcbiAgICAgIHNldEFsZXJ0TXNnVHlwZShcImVycm9yXCIpO1xyXG4gICAgICBzZXRTaG93U3VibWl0UmVzdWx0KHRydWUpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgcmV0dXJuIChcclxuICAgIDxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIG9uQ2xpY2s9e2hhbmRsZVN1Ym1pdH0gZGlzYWJsZWQ9e2xvYWRpbmd9PlxyXG4gICAgICBTdWJtaXRcclxuICAgIDwvQnV0dG9uPlxyXG4gICk7XHJcbn07XHJcbmV4cG9ydCBkZWZhdWx0IFN1Ym1pdEJ1dHRvbjtcclxuIl0sIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlQ29udGV4dCIsImF4aW9zIiwiQnV0dG9uIiwiRm9ybUNvbnRleHQiLCJBbGVydENvbnRleHQiLCJSZXN1bHRDb250ZXh0IiwicmVtb3ZlRW1wdHkiLCJTdWJtaXRCdXR0b24iLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImZvcm1Db250ZXh0IiwiZm9ybSIsInJlc3VsdCIsInNldFJlc3VsdCIsInNldFNob3dTdWJtaXRSZXN1bHQiLCJzZXRBbGVydE1zZyIsInNldEFsZXJ0TXNnVHlwZSIsImhhbmRsZVN1Ym1pdCIsIkpTT04iLCJzdHJpbmdpZnkiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwicG9zdCIsImhlYWRlcnMiLCJ0aGVuIiwiZGF0YSIsImlkIiwicmVzIl0sInNvdXJjZVJvb3QiOiIifQ==