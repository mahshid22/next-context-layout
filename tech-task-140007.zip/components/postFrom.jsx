const PostFrom = (props) => {
  return props.children;
};

export default PostFrom;
