import { useState, useContext } from "react";
import axios from "axios";
import Button from "@mui/material/Button";
import { FormContext } from "@/context/formContex";
import { AlertContext } from "@/context/alertCotex";
import { ResultContext } from "@/context/resultContext";
import removeEmpty from "utils/removeEmptyFromObject";
const SubmitButton = () => {
  const [loading, setLoading] = useState(false);
  const formContext = useContext(FormContext);
  const { form } = formContext;
  const { result, setResult } = useContext(ResultContext);
  const { setShowSubmitResult, setAlertMsg, setAlertMsgType } =
    useContext(AlertContext);
  const handleSubmit = () => {
    // actually a handles form with react hook forms :)
    if (
      JSON.stringify(form) !== JSON.stringify(result) &&
      Object.keys(removeEmpty(form)).length
    ) {
      setLoading(true);
      setShowSubmitResult(false);
      axios
        .post("https://jsonplaceholder.typicode.com/posts", form, {
          headers: {
            "Content-type": "application/json; charset=UTF-8",
          },
        })
        .then((result) => {
          delete result.data.id;
          let res = { ...result.data };
          setShowSubmitResult(true);
          setLoading(false);
          setAlertMsg("you're message was submited successfully");
          setAlertMsgType("success");
          setResult(res);
        })
        .catch(() => {
          setShowSubmitResult(true);
          setLoading(false);
          setAlertMsg("you're message was NOT submited.");
          setAlertMsgType("error");
        });
    } else {
      setAlertMsg(" Duplicate or Empty information");
      setAlertMsgType("error");
      setShowSubmitResult(true);
    }
  };
  return (
    <Button variant="contained" onClick={handleSubmit} disabled={loading}>
      Submit
    </Button>
  );
};
export default SubmitButton;
