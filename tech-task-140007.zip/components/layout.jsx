import NavBar from "./navBar";
import PageHead from "./Head";
import styles from "../styles/Home.module.scss";

const Layout = ({ children }) => {
  return (
    <div className={styles.container}>
      <PageHead header="Submit new post" />
      <div className={styles.main}>
        <NavBar />
        {children}
      </div>
    </div>
  );
};

export default Layout;
