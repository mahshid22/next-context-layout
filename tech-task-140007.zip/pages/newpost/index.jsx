import Box from "@mui/material/Box";
import Layout from "@/components/layout";
import PostFrom from "@/components/postFrom";
import SubmitButton from "@/components/submitButton";
import InputText from "@/components/inputText";
import Alert from "@/components/alertMessage";
import { Provider } from "@/context/resultContext";
import { FormProvider } from "@/context/formContex";
import { AlertProvider } from "@/context/alertCotex";
import styles from "../../styles/PostForm.module.scss";

export default function NewPost() {
  return (
    <FormProvider>
      <AlertProvider>
        <Provider>
          <Box className={styles.formPaper}>
            <h2>New Post</h2>
            <PostFrom>
              <InputText name="name" label="name" />
              <InputText name="mobile" label="mobile" />
              <InputText
                name="description"
                label="description"
                multiline
                rows={4}
              />
            </PostFrom>
            <SubmitButton />
            <Alert />
          </Box>
        </Provider>
      </AlertProvider>
    </FormProvider>
  );
}
NewPost.getLayout = function getLayout(page) {
  return <Layout>{page}</Layout>;
};
